#' Example dataset for Trendy
#'
#' Example time-course dataset.
#'
#' @docType data
#'
#' @usage data(TrendyExData)
#'
#' @format data matrix
#'
#' @keywords datasets
#'
#' @examples data(TrendyExData)
"TrendyExData"